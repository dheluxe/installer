#!/bin/bash
##Dababase Server
HOST='23.111.143.210'
USER='creedsvp_user'
PASS='creedsvp_pass'
DB='creedsvp_database'
PORT='3306'